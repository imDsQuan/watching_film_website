<!DOCTYPE html>
<html lang="en">
    <head>
        @include('includes.head')
    </head>

    <body>
        <div class="container">

            @include('includes.sidebar')

            @yield('content')
        </div>

        <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
        <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
        <script src="{{ url('js/app.js') }}"></script>
        <script src="{{url('bootstrap/js/bootstrap.bundle.min.js')}}"></script>
    </body>
</html>
