<div class="navigation">
    <ul>
        <li>
            <a href="#">
                <span class="icon"><ion-icon name="logo-apple"></ion-icon></span>
                <span class="title">Brand Name</span>
            </a>
        </li>
        <li>
            <a href="#">
                <span class="icon"><ion-icon name="home-outline"></ion-icon></span>
                <span class="title">Dashboard</span>
            </a>
        </li>
        <li>
            <a href="#">
                <span class="icon"><ion-icon name="people-outline"></ion-icon></span>
                <span class="title">Customer</span>
            </a>
        </li>
        <li>
            <a href="#">
                <span class="icon"><ion-icon name="chatbox-outline"></ion-icon></span>
                <span class="title">Message</span>
            </a>
        </li>
        <li>
            <a href="#">
                <span class="icon"><ion-icon name="help-outline"></ion-icon></span>
                <span class="title">Help</span>
            </a>
        </li>
        <li>
            <a href="#">
                <span class="icon"><ion-icon name="settings-outline"></ion-icon></span>
                <span class="title">Settings</span>
            </a>
        </li>
        <li>
            <a href="#">
                <span class="icon"><ion-icon name="lock-closed-outline"></ion-icon></span>
                <span class="title">Password</span>
            </a>
        </li>
        <li>
            <a href="#">
                <span class="icon"><ion-icon name="log-out-outline"></ion-icon></span>
                <span class="title">Sign Out</span>
            </a>
        </li>
    </ul>
</div>
<?php /**PATH K:\Đồ án tốt nghiệp\watching_film_website\backend\resources\views/includes/sidebar.blade.php ENDPATH**/ ?>