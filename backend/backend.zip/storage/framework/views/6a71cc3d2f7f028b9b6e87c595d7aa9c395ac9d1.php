<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="utf-8">
    <title>Animated Login Form | CodingNepal</title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/app.css')); ?>">
</head>
<body>
<div class="login-page">
    <div class="center">
        <h1>Login</h1>
        <?php if(count($errors) >0): ?>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="text-danger"> <?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>
        <form action="login" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="txt_field">
                <input type="text" name="username" required>
                <span></span>
                <label>Username</label>
            </div>
            <div class="txt_field">
                <input type="password" name="password" required>
                <span></span>
                <label>Password</label>
            </div>
            <input type="submit" value="Login">
        </form>
    </div>
</div>

</body>
</html>
<?php /**PATH K:\Đồ án tốt nghiệp\watching_film_website\backend\resources\views/login.blade.php ENDPATH**/ ?>