<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>

    <body>
        <div class="container">

            <?php echo $__env->make('includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php echo $__env->yieldContent('content'); ?>
        </div>

        <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
        <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
        <script src="<?php echo e(url('js/app.js')); ?>"></script>
        <script src="<?php echo e(url('bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    </body>
</html>
<?php /**PATH K:\Đồ án tốt nghiệp\watching_film_website\backend\resources\views/layouts/default.blade.php ENDPATH**/ ?>